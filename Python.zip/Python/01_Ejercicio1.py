a = int(input("Dame A: "))
b = int(input("Dame B: "))
c = int(input("Dame C: "))

y = (a+b+c)/(a*b)

print(f"El resultado es de: {y}")