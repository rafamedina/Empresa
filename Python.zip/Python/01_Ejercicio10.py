total = float(input("Dime el total de ventas realizadas: "))

comision = (total*0.08)

print(f"La comision del total es de un {comision}")