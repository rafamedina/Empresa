import math
a = float(input("Dame el primer valor: "))
b = float(input("Dame el segundo valor: "))

calculo = math.sqrt((a*a)+(b*b))

print(f"El resultado es de : {calculo}")