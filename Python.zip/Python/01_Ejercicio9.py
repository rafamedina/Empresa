importe = float(input("Dime el importe total: "))

importe -= importe * 0.15

print(f"El total es de {importe}")