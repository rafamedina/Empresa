precio = float(input("Dame el precio base: "))
iva = 0.21

preciofinal = precio + (precio * iva)

print(f"el precio final es de: {preciofinal}")