nota1 = float(input("Dame la nota 1: "))
nota2 = float(input("Dame la nota 2: "))
nota3 = float(input("Dame la nota 3: "))

media = (nota1+nota2+nota3)/ 3

print(f"La media es de {media}")