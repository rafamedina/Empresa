altura = float(input("Dame la altura: "))
base = float(input("Dame la base: "))

area = base * altura

perimetro = (2*(base * altura))

print(f"el area es de: {area} y el perimetro es de: {perimetro}")