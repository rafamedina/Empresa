kilometros = float(input("Dime los kilometros: "))
litros = float(input("Dime los litros consumidos: "))

consumo = (litros / kilometros) * 100

print(f"El consumo es de {consumo} a los 100")